<?php
/*
  Plugin Name: Remote Database Login
  Description: A plugin that allows users to login with a username and password, and checks if the user exists in a remote database.
  Version: 1.0
  Author: Nxvermore
*/

// Create a new menu item in the admin panel
add_action( 'admin_menu', 'remote_database_login_menu' );
function remote_database_login_menu() {
  add_options_page( 'Remote Database Login', 'Remote Database Login', 'manage_options', 'remote-database-login', 'remote_database_login_options' );
}

// Create a new options page for the plugin
function remote_database_login_options() {
  if ( !current_user_can( 'manage_options' ) )  {
    wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
  }

  // Check if the form has been submitted
  if (isset($_POST['submit'])) {
    // Get the username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Connect to the remote database
    $host = "hostname";
    $dbusername = "username";
    $dbpassword = "password";
    $dbname = "database_name";
    $conn = mysqli_connect($host, $dbusername, $dbpassword, $dbname);

    // Check if the username and password match a user in the remote database
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
      // Login is successful, redirect to another admin page
      echo '<div class="updated notice"><p>Logueado con éxito</p></div>';
    } else {
      // Login is not successful, display "Invalid username or password" message
      echo '<div class="error notice"><p>Invalid username or password</p></div>';
    }
  }

  // Display the login form
  echo '
  <div class="wrap">
    <h1>Remote Database Login</h1>
    <form method="post" action="">
      <label for="username">Username:</label>
      <input type="text" id="username" name="username" required>
      <br>
      <label for="password">Password:</label>
      <input type="password" id="password" name="password" required>
      <br>
      <input type="submit" name="submit" value="Login">
    </form>
  </div>
  ';
}